======== SYTLES ========

Navigation container
	background: black;

Navigation anchors
	color: #cccccc;

Navigation :hover
	color: #ffffff
	background-color: #ff7401

======== INSTRUCTIONS ========

1) Apply the above styling to the markup in index.html

2) Apply the hover styling to the <a> tags using the :hover pseudo class

3) Make sure to display the <a> tags as inline-block elements

4) Add padding to the <a> tags to increase their height and width

Bonus: figure out how to remove the space between the elements
