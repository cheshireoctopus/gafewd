Three Google Fonts are being used:
"Source Sans Pro"
"Merriweather"
"Oswald"

The yellow on the page is the CSS color name - "yellow".

Select styles are below. Approximate box model values as best as you can.

body
font-family: "Source Sans Pro"

h1 
color: yellow;
font-family: "Merriweather", serif;
font-size: 30px;

.tagline
font-family: "Merriweather", serif;
font-size: 25px;
background: #C6C6C6;

h2
font-size: 30px;
font-weight: bold;

h3
"Merriweather", serif;
font-size: 25px;

Nav Links
color: yellow;

Designer / Developer Nav Links
font-family: "Oswald", sans-serif;

Buttons
font-family: "Oswald";

Callout Button 
background: #C6C6C6;
